package com.example.phantom_signature_image

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
